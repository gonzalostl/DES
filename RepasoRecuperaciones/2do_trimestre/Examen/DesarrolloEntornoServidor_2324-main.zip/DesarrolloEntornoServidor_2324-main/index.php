<HTML>
<HEAD>
<TITLE> PAGINA INICIAL DES </TITLE>
</HEAD>
<BODY>

ESTE FICHERO ESTA EN EL DIRECTORIO 



<?php

$edad = 23;
$edad = "treinta y cinco";

echo "aleatorio ".random_int(23,28);
echo getcwd();

echo "<img src=img\FOTOYURIA.png />";

print "<h1> Encabezado 1 </h1>";

?>


</BODY>
</HTML>