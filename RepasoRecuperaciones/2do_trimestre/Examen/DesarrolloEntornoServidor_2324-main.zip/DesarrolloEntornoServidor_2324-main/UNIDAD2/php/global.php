<?php 

//Definimos array de palos
$nombre_palo =["Corazones","Picas","Treboles","Diamantes"];
$nombre_carta =["As","Dos","Tres","Cuatro","Cinco","Seis","Siete","Ocho","Nueve","Diez","J","Q","K"];

const MAX_HP =2000;


?>