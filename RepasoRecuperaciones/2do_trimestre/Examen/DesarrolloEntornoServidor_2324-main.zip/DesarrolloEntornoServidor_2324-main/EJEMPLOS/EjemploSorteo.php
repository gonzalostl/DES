<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
    
    $lista_profesores = ["Pablo","Charo","Cristina","Rocio","Carmen","Juanjo","Fabian","Fernando"];

    $num_agraciado = rand(0,7);

    echo " El numero agraciado es el $num_agraciado correspondiente al profesor $lista_profesores[$num_agraciado]";
    $a=200;
    $b=300;
    echo $a."0"+$b+"0";
    ?>
</body>
</html>